// Initialize the function
function word_counter(word){
  console.log(word);
  // Convert string to an array of words
  // An object to hold word frequency
  wordlist = {};
  // Iterate through the array and count the occurrence of each word
  word.split(" ").forEach(element => {
    if (!(element in wordlist)) {wordlist[element] = 0;}
    wordlist[element]++;
  });
  console.log(wordlist);
}
//  Call the function with the string as a parameter.
word_counter("I yam what I yam and always will be what I yam");