// grab references to the input element and the output div
// @TODO: YOUR CODE HERE

var output = d3.select(".output");
var text = d3.select("#text");

// Function to reverse a string
function reverseString(str) {
  return str.split("").reverse().join("");
}

// Function to handle input change
function handleChange(event) {
  // grab the value of the input field
  // @TODO: YOUR CODE HERE
  var val = text.property("value");
  console.log(val);
  console.log(reverseString(val));

  // clear the existing output
  // @TODO: YOUR CODE HERE
  output.text(reverseString(val));

  // reverse the input string
  // @TODO: YOUR CODE HERE

  // Set the output text to the reversed input string
  // @TODO: YOUR CODE HERE
}

// Attach an event to detect changes to the input field.
// @TODO: YOUR CODE HERE
text.on("change", handleChange);
