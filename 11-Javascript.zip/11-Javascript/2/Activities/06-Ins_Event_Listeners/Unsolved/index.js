var botton1 = d3.select("#click-me");
var botton2 = d3.select("#input-field");
console.log(botton1);
console.log(Object.entries(botton1));

botton1.on("click", function(){
    alert("WHAT!");
});

botton2.on("keyup", function(){
    alert(botton2.property("value"));
})