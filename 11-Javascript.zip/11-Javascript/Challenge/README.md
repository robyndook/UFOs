# The Truth is Out There

In this module, students will build a dynamic table using JavaScript and incorporate it into a web site using HTML, CSS and Bootstrap.
