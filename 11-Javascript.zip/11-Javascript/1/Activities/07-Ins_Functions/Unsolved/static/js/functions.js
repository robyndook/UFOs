// # Simple console.log statement
function print_hello(){
    console.log("Hello there!");
}
print_hello();

// # Takes two numbers and adds them
function addition(a, b){
    return a + b;
}

console.log(addition(10, 25));

// # Takes in a list and loops through
function list_loop(user_list){
    for (let i=0; i<user_list.length;i++){
        console.log(i)
    }
    return true;
}
var aaa = [1, 5, 65, 84];

console.log(list_loop(aaa));

// # Uses a previous declared function
function double_addition(c, d){
    let total = addition(c, d) * 2;
    return total
}

console.log(double_addition(10, 25));

// # Call the functions below

// # Run console.log function
print_hello()

// # console.log result of addition function
console.log(addition(44, 50))

// # Create a list and pass through the loop function
friends = ["Sarah", "Greg", "Cindy", "Jeff"]
list_loop(friends)

// # console.log result of double_addition function
console.log(double_addition(3, 4))

// # Python built in function for rounding
long_decimal = 112.34534454;
rounded_decimal = Math.round(long_decimal);
console.log(rounded_decimal);
