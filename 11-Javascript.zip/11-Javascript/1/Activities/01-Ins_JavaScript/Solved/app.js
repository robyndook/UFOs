
// This code will run when linked to in HTML
console.log("My script is stored outside of the HTML!")

/*

Multi
Line
Comment

*/

// Crate a variable called 'name' that holds a string
var full_name = "Khaled Karman";

// # Create a variable called 'country' that holds a string
var country = "United States";

// # Create a variable called 'age' that holds an integer
var age = 25;

// # Create a variable called 'hourly_wage' that holds an integer
var hourly_wage = 15;

// # Calculate the daily wage for the user
var daily_wage = hourly_wage * 8;

// # Create a variable that holds a number as a string
var weekly_hours = "40";

// # Create a variable called 'weekly_wage' that converts a string into an integer
var weekly_wage = hourly_wage * parseInt(weekly_hours);

// # Create a variable called 'satisfied' that holds a boolean
var satisfied = true;

// # console.log out "Hello <name>!"
console.log(`Hello, ${full_name}!`);

// # console.log out what country the user entered
console.log(`You live in ${country}.`);

// # console.log out the user's age
console.log(`You are ${age} years old.`);

// # console.log out the daily wage that was calculated
console.log(`You make ${daily_wage} dollars per day.`)

// # console.log out the weekly wage
console.log("You make " + weekly_wage + " dollars per week.")

// # Using an IF statement to console.log out whether the users were satisfied
if (satisfied){
    console.log("You are satisfied with your pay.")
} else {
    console.log("You are not satisfied with your pay.")
}

var x = 1;
var y = 10;

// # Checks if one value is equal to another
if (x === 1){
    console.log("x is equal to 1");
}

// # Checks if one value is NOT equal to another
if (y !== 1) {
    console.log("y is not equal to 1");
}

// # Checks if one value is less than another
if (x < y){
    console.log("x is less than y");
}

// # Checks if one value is greater than another
if (y > x){
    console.log("y is greater than x");
}

// # Checks if a value is less than or equal to another
if (x >= 1){
    console.log("x is greater than or equal to 1");
}

// # Checks for two conditions to be met using "and"
if (x == 1 && y == 10){
    console.log("Both values returned true");
}

// # Checks if either of two conditions is met
if (x < 45 || y < 5){
    console.log("One or the other statements were true");
}

// # if-elif-else
if (y < 5){
    console.log("x is less than 10 and y is less than 5");
}else if (y == 5){
    console.log("x is less than 10 and y is equal to 5");
}
else{
    console.log("x is less than 10 and y is greater than 5");
}

// # Nested if statements
if (x < 10){
    if (y < 5){
        console.log("x is less than 10 and y is less than 5");
    }else if (y == 5){
        console.log("x is less than 10 and y is equal to 5");
    }else{
        console.log("x is less than 10 and y is greater than 5");
    }
}