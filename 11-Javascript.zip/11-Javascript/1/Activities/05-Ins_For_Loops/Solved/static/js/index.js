// Prototypical use case increments loop counter by one on each iteration

// for x in list:
//   print(x)

for (var i = 0; i < 10; i++) {
  console.log("Iteration #", i);
}

// Looping through an array
var students = ["Johnny", "Tyler", "Bodhi", "Pappas"];
console.log(students);


for (var j = 0; j < students.length; j++) {
  console.log(students[j]);
}
